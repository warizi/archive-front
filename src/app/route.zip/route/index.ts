import { DefaultRouter } from "./model/router";

export { DefaultRouter };